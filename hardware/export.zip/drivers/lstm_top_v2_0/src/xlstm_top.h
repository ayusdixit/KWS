// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2022.2 (64-bit)
// Tool Version Limit: 2019.12
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// ==============================================================
#ifndef XLSTM_TOP_H
#define XLSTM_TOP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlstm_top_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
    u16 DeviceId;
    u64 Control_BaseAddress;
} XLstm_top_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLstm_top;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLstm_top_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLstm_top_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLstm_top_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLstm_top_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
int XLstm_top_Initialize(XLstm_top *InstancePtr, u16 DeviceId);
XLstm_top_Config* XLstm_top_LookupConfig(u16 DeviceId);
int XLstm_top_CfgInitialize(XLstm_top *InstancePtr, XLstm_top_Config *ConfigPtr);
#else
int XLstm_top_Initialize(XLstm_top *InstancePtr, const char* InstanceName);
int XLstm_top_Release(XLstm_top *InstancePtr);
#endif

void XLstm_top_Start(XLstm_top *InstancePtr);
u32 XLstm_top_IsDone(XLstm_top *InstancePtr);
u32 XLstm_top_IsIdle(XLstm_top *InstancePtr);
u32 XLstm_top_IsReady(XLstm_top *InstancePtr);
void XLstm_top_EnableAutoRestart(XLstm_top *InstancePtr);
void XLstm_top_DisableAutoRestart(XLstm_top *InstancePtr);

void XLstm_top_Set_input_data(XLstm_top *InstancePtr, u64 Data);
u64 XLstm_top_Get_input_data(XLstm_top *InstancePtr);
void XLstm_top_Set_dense_output(XLstm_top *InstancePtr, u64 Data);
u64 XLstm_top_Get_dense_output(XLstm_top *InstancePtr);

void XLstm_top_InterruptGlobalEnable(XLstm_top *InstancePtr);
void XLstm_top_InterruptGlobalDisable(XLstm_top *InstancePtr);
void XLstm_top_InterruptEnable(XLstm_top *InstancePtr, u32 Mask);
void XLstm_top_InterruptDisable(XLstm_top *InstancePtr, u32 Mask);
void XLstm_top_InterruptClear(XLstm_top *InstancePtr, u32 Mask);
u32 XLstm_top_InterruptGetEnabled(XLstm_top *InstancePtr);
u32 XLstm_top_InterruptGetStatus(XLstm_top *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
